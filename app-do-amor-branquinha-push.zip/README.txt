# App do Amor da Branquinha — Push
Frontend + servidor Node para **notificações push reais** (mesmo com o app fechado).

## Como rodar localmente
1) Instale Node 18+
2) Terminal:
   ```bash
   cd server
   npm install
   npm run generate-keys   # cria .env com VAPID_PUBLIC_KEY/PRIVATE_KEY
   npm start               # http://localhost:8888
   ```
3) No navegador, abra http://localhost:8888
4) No app: clique em **Permitir Notificações** e depois **Inscrever Push**
5) Ajuste horários e **Salvar** — o servidor enviará push nos horários (TZ: America/Sao_Paulo).
6) Botão **Testar Agora** dispara um push imediato.

## Deploy (Render / Railway / VPS)
- Suba a pasta `server/` como serviço Node.
- Defina as env vars: VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_CONTACT.
- O servidor já serve a pasta `frontend/` automaticamente.

Dados são salvos em `server/subs.json` e `server/schedule.json`.
